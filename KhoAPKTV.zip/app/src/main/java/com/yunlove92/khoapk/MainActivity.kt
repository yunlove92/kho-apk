package com.yunlove92.khoapk

import android.app.*
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val jsonUrl = "https://raw.githubusercontent.com/yunlove92/kho-apk/main/apps.json"
    private lateinit var list: LinearLayout
    private val client = OkHttpClient()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(55,35,55,35); setBackgroundColor(0xFF080B10.toInt()) }
        val title = TextView(this).apply { text="KHO APK TV"; textSize=30f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,0,0,25) }
        root.addView(title)
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        load()
    }

    private fun load() {
        list.removeAllViews()
        val loading=TextView(this).apply{text="Đang tải danh sách...";textSize=20f;setTextColor(-1)}
        list.addView(loading)
        thread {
            try {
                val body=client.newCall(Request.Builder().url(jsonUrl).build()).execute().body?.string() ?: ""
                val arr=JSONObject(body).getJSONArray("apps")
                runOnUiThread {
                    list.removeAllViews()
                    for(i in 0 until arr.length()) {
                        val o=arr.getJSONObject(i)
                        val b=Button(this).apply {
                            text="${o.optString("name")}    •    v${o.optString("version")}"
                            textSize=20f; isFocusable=true; isFocusableInTouchMode=true
                            setOnClickListener { download(o.optString("name"), o.optString("url")) }
                        }
                        list.addView(b, LinearLayout.LayoutParams(-1,75).apply{setMargins(0,0,0,12)})
                    }
                    if(arr.length()==0) loading.text="Không có ứng dụng."
                }
            } catch(e:Exception) { runOnUiThread { loading.text="Không tải được apps.json\n${e.message}" } }
        }
    }

    private fun download(name:String, url:String) {
        val dialog=ProgressDialog(this).apply{setTitle("Đang tải $name");setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);max=100;setCancelable(false);show()}
        thread {
            try {
                val r=client.newCall(Request.Builder().url(url).build()).execute()
                if(!r.isSuccessful) throw Exception("HTTP ${r.code}")
                val file=File(cacheDir, "${name.replace(" ","_")}.apk")
                val total=r.body?.contentLength() ?: -1
                var done=0L
                FileOutputStream(file).use { out ->
                    r.body?.byteStream()?.use { input ->
                        val buf=ByteArray(8192); var n:Int
                        while(input.read(buf).also{n=it}!=-1){out.write(buf,0,n);done+=n;if(total>0) runOnUiThread{dialog.progress=(done*100/total).toInt()}}
                    }
                }
                runOnUiThread { dialog.dismiss(); install(file) }
            } catch(e:Exception){runOnUiThread{dialog.dismiss();Toast.makeText(this,"Lỗi tải: ${e.message}",Toast.LENGTH_LONG).show()}}
        }
    }

    private fun install(file:File) {
        if(Build.VERSION.SDK_INT>=26 && !packageManager.canRequestPackageInstalls()){
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            Toast.makeText(this,"Cho phép KHO APK TV cài ứng dụng, rồi chọn lại app.",Toast.LENGTH_LONG).show()
            return
        }
        val uri=Uri.fromFile(file)
        val i=Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,"application/vnd.android.package-archive");addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        try{startActivity(i)}catch(e:Exception){Toast.makeText(this,"Không mở được trình cài đặt: ${e.message}",Toast.LENGTH_LONG).show()}
    }
}
